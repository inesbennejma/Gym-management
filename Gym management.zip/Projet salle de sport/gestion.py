#!/usr/bin/env python
# coding: utf-8

# In[1]:


from tkinter import *
from Materiel import Materiel
import tkinter.ttk as ttk
from PIL import ImageTk,Image
import csv
import pandas as pd

class GestionMateriel():
    def __init__(self,root):
        self.root = root
        self.root.geometry('600x600')
        self.root.title("Gestion Materiel")
        self.root.configure(bg='thistle')
       
        self.id=StringVar()
        self.marque=StringVar()
        self.type=StringVar()
        #==============Num etudiant TEXTFIELD AND LABEL
        id_materiel_lbl = Label(self.root,text = "identifiant materiel",anchor='w')
        id_materiel_lbl.grid(row = 1,column = 0,padx = 40,pady = 40)
        id_materiel_field = Entry(self.root,textvariable = self.id)
        id_materiel_field.grid(row = 1,column = 1,ipady = 7,ipadx = 20,padx = 20)
 #==============Marque materiel TEXTFIELD AND LABEL
        marque_lbl = Label(self.root,text = "Marque materiel",anchor='w')
        marque_lbl.grid(row = 2,column = 0,padx = 40,pady = 40)
        marque_field = Entry(self.root,textvariable = self.marque)
        marque_field.grid(row = 2,column = 1,ipady = 7,ipadx = 20,padx = 20)
#=======================Prenom etudiant LABEL AND TEXTFIELD
        type_lbl = Label(self.root,text="Type Materiel",anchor='w')
        type_lbl.grid(row = 3,column = 0,pady = 40)
        type_field = Entry(self.root,textvariable = self.type)
        type_field.grid(row = 3,column = 1,ipady = 7,ipadx = 20,padx = 20)

        #=====================Boutton ajout
        ajou_materiel_btn = Button(self.root,text = "Ajouter",command = self.add,anchor='c', background="plum")
        ajou_materiel_btn.grid(row = 5,column = 0,ipady = 4,ipadx = 13,pady = 40)
        #=====================Boutton affichage à ajouter après boutton "Ajouter" dans __init()__
        affich_materiel_btn = Button(self.root,text = "Afficher",command = self.view,anchor='c',background="plum")
        affich_materiel_btn.grid(row = 5,column = 2,ipady = 4,ipadx = 13,pady = 40) 
        #=====================Boutton Supprimer à ajouter après boutton "Afficher" dans __init()__
        supp_materiel_btn = Button(self.root,text = "Supprimer",command = self.remove,anchor='c',background="plum")
        supp_materiel_btn.grid(row = 5,column = 1,ipady = 4,ipadx = 13,pady = 40)
        #button_Excel
        exel_materiel_btn = Button(self.root,text = "add to Excel",command = self.write_csv(),background="pink")
        exel_materiel_btn.grid(row = 6,column = 3,ipady = 4,ipadx = 13,pady = 40)
        
        html_btn = Button(self.root,text = "ajouter au fichier html",command = self.write_html,background="pink")
        html_btn.grid(row = 6,column = 1,ipady = 4,ipadx = 13,pady = 40)
        
        #play_button
        
        
        play_btn = Button(self.root,text = "play music",anchor='c',background="white")                               
        play_btn.grid(row = 1,column = 2,ipady = 4,ipadx = 12,pady = 12)
        
        
        
        #stop_button
        stop_btn = Button(self.root,text = "stop music",anchor='c',background="white")
        stop_btn.grid(row = 2,column = 2,ipady = 4,ipadx = 13,pady = 40)
    #Fonction d'ajout d'un étudiant (sera appelée dérière le boutton "Ajouter"
    def add(self):
        M = Materiel(self.id.get(),self.marque.get(),self.type.get())
        print("Materiel: ",M.marque)
        M.ajouterMateriel()
    def view(self):
        #self.root.title("Student Management(Details)")
        #==========================Show Frame
        self.root=Tk()
        self.root.geometry('700x300')
        self.root.title("gestion materiel)")
        show_frame = Frame(self.root)
        show_frame.place(width = 800,x = 0,y = 0 ,height = 300)
        labl_show = Label(show_frame,text = "Affichage de materiel")
        labl_show.pack()
        
        #========================Main Frame
        main_frame = Frame(self.root,bd = 10,relief = SUNKEN)
        main_frame.place(width = 600,height = 200,x = 8,y = 58)
        tree = ttk.Treeview(main_frame,height = 200)
        vsb = ttk.Scrollbar(main_frame,command = tree.yview,orient = "vertical")
        tree.configure(yscroll = vsb.set)
        vsb.pack(side = RIGHT,fill = Y)
        tree.pack(side = TOP,fill = X)
        tree['columns'] = ("1","2","3")
        tree.column('#0',width=50)
        tree.column('1',width=80)
        tree.column('2',width=80)
        tree.column('3',width=80)
        tree.heading("#0",text = "Num",anchor='c')
        tree.heading("1",text = "id",anchor='c')
        tree.heading("2",text = "Marque",anchor='w')
        tree.heading("3",text = "Type",anchor='w')
        
        M=Materiel()
        rows=M.afficherMateriel()
        j=1
        for i in rows:
            tree.insert("","end",text=str(j), values = (f'{i[0]}',f'{i[1]}',f'{i[2]}'))
            j+=1
    #Fonction dse suppression d'un materiel sera appelée dans le boutton "Supprimer"  
    def remove(self):
        M = Materiel()
        M.supprimerMateriel(self.id.get())
        
    
    def write_csv(self):
            M=Materiel()
            with open('materiel.csv', 'w') as f:
                w=csv.writer(f)
                w.writerow([M.afficherMateriel()])
                
    def write_html(self):
        
        CSV=pd.read_csv("materiel2.csv")
        CSV.to_html("materiel2.html")
        
 
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
#if __name__ == "__main__":
root = Tk()
l = GestionMateriel(root)
root.mainloop()


# In[ ]:





# In[ ]:





# In[ ]:




