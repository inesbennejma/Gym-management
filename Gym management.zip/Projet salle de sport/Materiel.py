#!/usr/bin/env python
# coding: utf-8

# In[1]:



import mysql.connector

class Materiel:
  #  db=connect_BD()
   # mycursor=db.cursor()
    def __init__(self,ident=0,mq="",ty=""):
        self.id=ident
        self.marque=mq
        self.type=ty
        self.db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root123456",
        database="salle_de_sport"
        )
        self.mycursor=self.db.cursor()
    #fonction d'ajout dans la table materiel
    def ajouterMateriel(self):
        sql = "INSERT INTO materiel (id, marque,type) VALUES (%s, %s, %s)"
        val = (self.id, self.marque, self.type)
        self.mycursor.execute(sql, val)
        self.db.commit()
        print(self.mycursor.rowcount, "record inserted.")#optionnel
    #fonction d'affichage de tous le materiel
    def afficherMateriel(self):
        self.mycursor.execute('SELECT * FROM materiel')
        result=self.mycursor.fetchall()
        return result
        #for row in self.mycursor:
        #print(row)
    #fonction supprimer materiel
    def supprimerMateriel(self,ident):
        sql = "DELETE FROM materiel WHERE id = %s"
        val = (ident,)
        self.mycursor.execute(sql, val)
        self.db.commit()
        
    def modifierMateriel(self):
        sql = "UPDATE materiel SET marque='%s',type='%s' WHERE id = %s"
        val = (self.id, self.marque, self.type)
        self.mycursor.execute(sql)
        self.db.commit()
    
        


# def modifierMateriel(self,id,marque,type):
        #sql = "UPDATE materiel SET marque= %s,type= %s WHERE id = %s"
        #val = (self.id, self.marque, self.type)
        #self.mycursor.execute(sql,val)
        #self.db.commit()




