import mysql.connector
#def connect_BD():
#    mydb = mysql.connector.connect(
#        host="localhost",
#        user="naouel",
#        password="naouel",
#        database="naoueldb"
#        )
#    return mydb
#Classe Etudiant
class Abonnee:
  #  db=connect_BD()
   # mycursor=db.cursor()
    def __init__(self,idab="",nm="",pr="",ag=0,fa=0):
        self.id_abonne=idab
        self.nom=nm
        self.prenom=pr
        self.age=ag
        self.frais_inscription=fa
        self.db = mysql.connector.connect(
        host="localhost",
        user="Ines",
        password="Inesbennejma24",
        database='salle_de_sport'
        )
        self.mycursor=self.db.cursor()
    #fonction d'ajout dans la table 
    def ajouterAbonnee (self):
        sql = "INSERT INTO abonnee (id_abonne, nom, prenom, age, frais_inscription) VALUES (%s, %s, %s, %s, %s)"
        val = (self.id_abonne, self.nom, self.prenom, self.age, self.frais_inscription)
        self.mycursor.execute(sql, val)
        self.db.commit()
        print(self.mycursor.rowcount, "abonnee inserted.")#optionnel
    #fonction d'affichage 
    def afficherAbonnee(self):
        self.mycursor.execute('SELECT * FROM abonnee')
        result=self.mycursor.fetchall()
        return result
        #for row in self.mycursor:
        #print(row)
    #fonction supprimer 
    def supprimerAbonnee(self,idab):
        sql = "DELETE FROM abonnee WHERE id_abonne = %s"
        val = (idab,)
        self.mycursor.execute(sql, val)
        self.db.commit()
        
