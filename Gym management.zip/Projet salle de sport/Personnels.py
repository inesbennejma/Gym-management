#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import mysql.connector

#Classe Personnel
class Personnels:
    #db=connect_BD()
    #mycursor=db.cursor()
    def __init__(self,id_personnel=0, nom="", prenom="", date=""):
        self.id_personnel=id_personnel
        self.nom=nom
        self.prenom=prenom
        self.date_naissance=date
        self.db = mysql.connector.connect(
        host="localhost",
        user="Ines",
        password="Inesbennejma24",
        database='salle_de_sport'
        )
        self.mycursor=self.db.cursor()
    #fonction d'ajout dans la table personnel
    def ajouterPersonnel (self):
        sql = "INSERT INTO tab_personnels (id_personnel, nom, prenom, date_naissance) VALUES (%s, %s, %s, %s)"
        val = (self.id_personnel, self.nom, self.prenom, self.date_naissance)
        self.mycursor.execute(sql, val)
        self.db.commit()
        print(self.mycursor.rowcount, "record inserted.")#optionnel
    #fonction d'affichage de tous les personnels
    def afficherPersonnel(self):
        self.mycursor.execute('SELECT * FROM tab_personnels')
        result=self.mycursor.fetchall()
        return result
        #for row in self.mycursor:
        #print(row)
    #fonction supprimer personnel
    def supprimerPersonnel(self,id_personnel):
        sql = "DELETE FROM tab_personnels WHERE id_personnel = %s"
        val = (id_personnel,)
        self.mycursor.execute(sql, val)
        self.db.commit()
    

