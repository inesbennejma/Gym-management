import mysql.connector
#def connect_BD():
#    mydb = mysql.connector.connect(
#        host="localhost",
#        user="naouel",
#        password="naouel",
#        database="naoueldb"
#        )
#    return mydb
#Classe Etudiant
class Cours:
  #  db=connect_BD()
   # mycursor=db.cursor()
    def __init__(self,idc="",nm="",co="",hor=""):
        self.id=idc
        self.nom=nm
        self.coach=co
        self.horaire=hor
        self.db = mysql.connector.connect(
        host="localhost",
        user="Ines",
        password="Inesbennejma24",
        database='salle_de_sport'
        )
        self.mycursor=self.db.cursor()
    #fonction d'ajout 
    def ajouterCours (self):
        sql = "INSERT INTO cours (id, nom, coach, horaire) VALUES (%s, %s, %s, %s)"
        val = (self.id, self.nom, self.coach, self.horaire)
        self.mycursor.execute(sql, val)
        self.db.commit()
        print(self.mycursor.rowcount, "cours inserted.")#optionnel
    #fonction d'affichage
    def afficherCours(self):
        self.mycursor.execute('SELECT * FROM cours')
        result=self.mycursor.fetchall()
        return result
        #for row in self.mycursor:
        #print(row)
    #fonction supprimer
    def supprimerCours(self,idc):
        sql = "DELETE FROM cours WHERE id = %s"
        val = (idc,)
        self.mycursor.execute(sql, val)
        self.db.commit()
        
