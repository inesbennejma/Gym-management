#!/usr/bin/env python
# coding: utf-8

# In[5]:


from tkinter import *
from Fournisseur import Fournisseur
import tkinter.ttk as ttk
import csv
import pygame
import pandas as pd



class GestionFournisseur():
    def __init__(self,root):
        self.root = root
        self.root.geometry('620x620')
        self.root.title("Gestion Fournisseur")
        self.root.configure(bg='thistle')
        self.id=StringVar()
        self.numf=StringVar()
        self.nom=StringVar()
        self.domaine=StringVar()
        self.adresse=StringVar()
        
        
        
        
    
        
        
    #==============Num etudiant TEXTFIELD AND LABEL
        num_fournisseur_lbl = Label(self.root,text = "identifiant fournisseur",anchor='w')
        num_fournisseur_lbl.grid(row = 1,column = 0,padx = 40,pady = 40)
        num_fournisseur_field = Entry(self.root,textvariable = self.numf)
        num_fournisseur_field.grid(row = 1,column = 1,ipady = 7,ipadx = 20,padx = 20)
       
 #==============Nom etudiant TEXTFIELD AND LABEL
        nom_fournisseur_lbl = Label(self.root,text = "Nom fournisseur",anchor='w')
        nom_fournisseur_lbl.grid(row = 2,column = 0,padx = 40,pady = 40)
        nom_fournisseur_field = Entry(self.root,textvariable = self.nom)
        nom_fournisseur_field.grid(row = 2,column = 1,ipady = 7,ipadx = 20,padx = 20)
       
 #=======================Prenom etudiant LABEL AND TEXTFIELD
        domaine_lbl = Label(self.root,text="domaine fournisseur",anchor='w')
        domaine_lbl.grid(row = 3,column = 0,pady = 40)
        domaine_field = Entry(self.root,textvariable = self.domaine)
        domaine_field.grid(row = 3,column = 1,ipady = 7,ipadx = 20,padx = 20)
#=======================Age etudiant LABEL AND TEXTFIELD
        adresse_lbl = Label(self.root,text="adresse fournisseur",anchor='w')
        adresse_lbl.grid(row = 4,column = 0,pady = 40)
        adresse_field = Entry(self.root,textvariable = self.adresse)
        adresse_field.grid(row = 4,column = 1,ipady = 7,ipadx = 20,padx = 20)



        #=====================Boutton ajout
        add_btn = Button(self.root,text = "Ajouter",command = self.add,anchor='c',background="plum")
        add_btn.grid(row = 5,column = 0,ipady = 4,ipadx = 30,pady = 40)
        #=====================Boutton affichage à ajouter après boutton "Ajouter" dans __init()__
        affich_btn = Button(self.root,text = "Afficher",command = self.view,anchor='c',background="plum")
        affich_btn.grid(row = 5,column = 2,ipady = 4,ipadx = 13,pady = 40) 
        #=====================Boutton Supprimer à ajouter après boutton "Afficher" dans __init()__
        supp_btn = Button(self.root,text = "Supprimer",command = self.remove,anchor='c',background="plum")
        supp_btn.grid(row = 5,column = 1,ipady = 4,ipadx = 13,pady = 40)
       
         #button_Excel
        exel_btn = Button(self.root,text = "ajouter au fichier Excel",command=self.write_csv,background="plum") 
        exel_btn.grid(row = 6,column = 2,ipady = 4,ipadx = 5,pady = 20)
        
        play_btn = Button(self.root,text ='play music',anchor='c',background="pink")                               
        play_btn.grid(row = 1,column = 2,ipady = 4,ipadx = 12,pady = 12)
        
        
        
        #stop_button
        stop_btn = Button(self.root,text ='stop music',anchor='c',background="pink")
        stop_btn.grid(row = 2,column = 2,ipady = 4,ipadx = 13,pady = 40)
        
    #Fonction d'ajout d'un fournisseur (sera appelée dérière le boutton "Ajouter"
    def add(self):
        F= Fournisseur(self.numf.get(),self.nom.get(),self.domaine.get(),self.adresse.get())
        print("Fournisseur: ",F.nom)
        F.ajouterFournisseur()
        
   
    
    def view(self):
        #self.root.title("Fournisseur Management(Details)")
        #==========================Show Frame
        self.root=Tk()
        self.root.geometry('700x300')
        self.root.title("gestion fournisseur")
        show_frame = Frame(self.root)
        show_frame.place(width = 800,x = 0,y = 0 ,height = 300)
        show_frame.configure(bg="honeydew")
        labl_show = Label(show_frame,text = "Affichage de fournisseur")
        labl_show.pack()
        #========================Main Frame
        main_frame = Frame(self.root,bd = 10,relief = SUNKEN)
        main_frame.place(width = 600,height = 200,x = 8,y = 58)
        main_frame.configure(bg="green")
        tree = ttk.Treeview(main_frame,height = 200)
        vsb = ttk.Scrollbar(main_frame,command = tree.yview,orient = "vertical")
        tree.configure(yscroll = vsb.set)
        vsb.pack(side = RIGHT,fill = Y)
        tree.pack(side = TOP,fill = X)
        tree['columns'] = ("1","2","3","4")
        tree.column('#0',width=50)
        tree.column('1',width=80)
        tree.column('2',width=80)
        tree.column('3',width=80)
        tree.column('4',width=80)
        tree.heading("#0",text = "Num",anchor='c')
        tree.heading("1",text = "numf",anchor='c')
        tree.heading("2",text = "nom",anchor='w')
        tree.heading("3",text = "domaine",anchor='w')
        tree.heading("4",text = "adresse",anchor='w')
        
        F=Fournisseur()
        rows=F.afficherFournisseur()
        j=1
        for i in rows:
            tree.insert("","end",text=str(j), values = (f'{i[0]}',f'{i[1]}',f'{i[2]}',f'{i[3]}'))
            j+=1
        
            
    #Fonction dse suppression d'un fournisseur sera appelée dans le boutton "Supprimer"  
    def remove(self):
        F = Fournisseur()
        F.supprimerFournisseur(self.numf.get())
    
          
            

        
    def write_csv(self):
        F=Fournisseur()
        with open('fourni.csv', 'w') as f:
            w=csv.writer(f)
            w.writerow([F.afficherFournisseur()])
        
        

    

        
        
        
        
    

        
 
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
#if __name__ == "__main__":
root = Tk()
l = GestionFournisseur(root)
root.mainloop()


# In[ ]:




