#!/usr/bin/env python
# coding: utf-8

# In[1]:


from tkinter import *
from Cours import Cours
import tkinter.ttk as ttk
from PIL import ImageTk,Image
import csv
import pygame
import smtplib

class GestionCours():
    def __init__(self,root):
        self.root = root
        self.root.geometry('600x650')
        self.root.title("Gestion Cours")
        self.root.configure(bg="plum")        
  
        self.id=StringVar()
        self.nom=StringVar()
        self.coach=StringVar()
        self.horaire=StringVar()
                
        pygame.mixer.init()
        
        
        
    #==============Num etudiant TEXTFIELD AND LABEL
        id_cours_lbl = Label(self.root,text = "identifiant cours",anchor='w')
        id_cours_lbl.grid(row = 1,column = 0,padx = 40,pady = 40)
        id_cours_field = Entry(self.root,textvariable = self.id)
        id_cours_field.grid(row = 1,column = 1,ipady = 7,ipadx = 20,padx = 20)
 #==============Nom etudiant TEXTFIELD AND LABEL
        nom_lbl = Label(self.root,text = "Nom cours",anchor='w')
        nom_lbl.grid(row = 2,column = 0,padx = 40,pady = 40)
        nom_field = Entry(self.root,textvariable = self.nom)
        nom_field.grid(row = 2,column = 1,ipady = 7,ipadx = 20,padx = 20)
#=======================Prenom etudiant LABEL AND TEXTFIELD
        coach_lbl = Label(self.root,text="coach cours",anchor='w')
        coach_lbl.grid(row = 3,column = 0,pady = 40)
        coach_field = Entry(self.root,textvariable = self.coach)
        coach_field.grid(row = 3,column = 1,ipady = 7,ipadx = 20,padx = 20)
#=======================Age etudiant LABEL AND TEXTFIELD
        horaire_lbl = Label(self.root,text="horaire cours",anchor='w')
        horaire_lbl.grid(row = 4,column = 0,pady = 40)
        horaire_field = Entry(self.root,textvariable = self.horaire)
        horaire_field.grid(row = 4,column = 1,ipady = 7,ipadx = 20,padx = 20)



        #=====================Boutton ajout
        ajou_cours_btn = Button(self.root,text = "Ajouter",command = self.add,anchor='c',background="hotpink",foreground="white" )
        
        ajou_cours_btn.grid(row = 6,column = 0,ipady = 5,ipadx = 30,pady = 40)
        #=====================Boutton affichage à ajouter après boutton "Ajouter" dans _init()_
        affich_cours_btn = Button(self.root,text = "Afficher",command = self.view,anchor='c',background="hotpink",foreground="white" )
        
        affich_cours_btn.grid(row = 6,column = 2,ipady = 5,ipadx = 13,pady = 40) 
        #=====================Boutton Supprimer à ajouter après boutton "Afficher" dans _init()_
        supp_cours_btn = Button(self.root,text = "Supprimer",command = self.remove,anchor='c',background="hotpink",foreground="white" )

        supp_cours_btn.grid(row = 6,column = 1,ipady = 5,ipadx = 13,pady = 40)
        
        
        
        
             #play_button
        
        
        play_btn = Button(self.root,command = self.play,text = "Play music",anchor='c',background="lavenderblush")
                                      
        play_btn.grid(row = 1,column = 3,ipady = 4,ipadx = 12,pady = 12)
        
        
        
        #stop_button
        stop_btn = Button(self.root,command = self.stop,text = "Stop music",anchor='c',background="lavenderblush")
        
        stop_btn.grid(row = 2,column = 3,ipady = 4,ipadx = 13,pady = 40)
        
                
        #button_Excel
        exel_btn = Button(self.root,text = "Excel",command = self.write_csv,background="purple",foreground="white")
        
        exel_btn.grid(row = 7,column = 0,ipady = 4,ipadx = 13,pady = 40)
        
                
        #button mail
        mail_btn = Button(self.root,text = "Send Mail",command = self.mail,anchor='c',background="purple",foreground="white")
        
        mail_btn.grid(row = 7,column = 1,ipady = 5,ipadx = 30,pady = 40)
        
        
    #Fonction d'ajout d'un fournisseur (sera appelée dérière le boutton "Ajouter"
    def add(self):
        C= Cours(self.id.get(),self.nom.get(),self.coach.get(),self.horaire.get())
        print("Cours: ",C.nom)
        C.ajouterCours()
    
    def view(self):
        #self.root.title("Fournisseur Management(Details)")
        #==========================Show Frame
        self.root=Tk()
        self.root.geometry('700x300')
        self.root.title("gestion cours)")
        show_frame = Frame(self.root)
        show_frame.place(width = 800,x = 0,y = 0 ,height =600)
        labl_show = Label(show_frame,text = "Affichage des cours")
        labl_show.pack()
        #========================Main Frame
        main_frame = Frame(self.root,bd = 10,relief = SUNKEN)
        main_frame.place(width = 600,height = 200,x = 8,y = 58)
        tree = ttk.Treeview(main_frame,height = 200)
        vsb = ttk.Scrollbar(main_frame,command = tree.yview,orient = "vertical")
        tree.configure(yscroll = vsb.set)
        vsb.pack(side = RIGHT,fill = Y)
        tree.pack(side = TOP,fill = X)
        tree['columns'] = ("1","2","3","4")
        tree.column('#0',width=50)
        tree.column('1',width=80)
        tree.column('2',width=80)
        tree.column('3',width=80)
        tree.column('4',width=80)
        
        tree.heading("#0",text = "Num",anchor='c')
        tree.heading("1",text = "id_cours",anchor='c')
        tree.heading("2",text = "nom",anchor='w')
        tree.heading("3",text = "coach",anchor='w')
        tree.heading("4",text = "horaire",anchor='w')
        
        
        C=Cours()
        rows=C.afficherCours()
        j=1
        for i in rows:
            tree.insert("","end",text=str(j), values = (f'{i[0]}',f'{i[1]}',f'{i[2]}',f'{i[3]}'))
            j+=1
    #Fonction dse suppression d'un fournisseur sera appelée dans le boutton "Supprimer"  
    def remove(self):
        C = Cours()
        C.supprimerCours(self.id.get())
 

             
    def play(self):
        pygame.mixer.music.load(r'music.mp3')
        pygame.mixer.music.play(loops=0)
        
    def stop(self):
        pygame.mixer.music.stop()   

        
        
    def write_csv(self):
        C=Cours()
        with open('cours2.csv', 'w') as f:
            w=csv.writer(f)
            w.writerow([C.afficherCours()])   
         

        
        
        
    def mail(self):
        sender_email = "rihabmansouri2016@gmail.com"
        rec_email = "rihab.mansouri@esprit.tn"
        password = input(str("please enter your password : "))
        message = input(str("please enter your message : "))
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, password)
        print("login success")
        server.sendmail(sender_email, rec_email, message)
        print("email has been sent to ", rec_email )     
        
        
        
        
        
            
        
        
        
        
        
        
        
#if _name_ == "_main_":
root = Tk()
l = GestionCours(root)
root.mainloop()



# In[ ]:




