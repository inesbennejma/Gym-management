#!/usr/bin/env python
# coding: utf-8

# In[2]:


from tkinter import *
from Materiel import Materiel
import tkinter.ttk as ttk
from PIL import ImageTk,Image
import pandas as pd
import csv
import pygame

class GestionMateriel():
    def __init__(self,root):
        self.root = root
        self.root.geometry('600x600')
        self.root.title("Gestion Materiel")
        self.id=StringVar()
        self.marque=StringVar()
        self.type=StringVar()
        
        pygame.mixer.init()
        
        self.playbuttonimage=Image.open(r'gym1.png')
        self.playbuttonimageph=ImageTk.PhotoImage(self.playbuttonimage)
        
        self.stopbuttonimage=Image.open(r'stop1.png')
        self.stopbuttonimageph=ImageTk.PhotoImage(self.stopbuttonimage)
        
        self.ajoutbuttonimage=Image.open(r'ajouter.png')
        self.ajoutbuttonimageph=ImageTk.PhotoImage(self.ajoutbuttonimage)
        
        self.affichbuttonimage=Image.open(r'liste.png')
        self.affichbuttonimageph=ImageTk.PhotoImage(self.affichbuttonimage)
        
        self.delbuttonimage=Image.open(r'del.png')
        self.delbuttonimageph=ImageTk.PhotoImage(self.delbuttonimage)
        
        self.exbuttonimage=Image.open(r'excel.png')
        self.exbuttonimageph=ImageTk.PhotoImage(self.exbuttonimage)
        
        self.htmlbuttonimage=Image.open(r'html.png')
        self.htmlbuttonimageph=ImageTk.PhotoImage(self.htmlbuttonimage)
        
        
        
        
        
        
        
      
        #==============Num materiel TEXTFIELD AND LABEL
        id_materiel_lbl = Label(self.root,text = "identifiant materiel",anchor='w' , bg="floralwhite",fg="darkorange")
        id_materiel_lbl.grid(row = 1,column = 0,padx = 40,pady = 40)
        id_materiel_field = Entry(self.root,textvariable = self.id)
        id_materiel_field.grid(row = 1,column = 1,ipady = 7,ipadx = 20,padx = 20)
 #==============Marque materiel TEXTFIELD AND LABEL
        marque_lbl = Label(self.root,text = "Marque materiel",anchor='w', bg="floralwhite",fg="darkorange")
        marque_lbl.grid(row = 2,column = 0,padx = 40,pady = 40)
        marque_field = Entry(self.root,textvariable = self.marque)
        marque_field.grid(row = 2,column = 1,ipady = 7,ipadx = 20,padx = 20)
#=======================type materiel LABEL AND TEXTFIELD
        type_lbl = Label(self.root,text="Type Materiel",anchor='w', bg="floralwhite",fg="darkorange")
        type_lbl.grid(row = 3,column = 0,pady = 40)
        type_field = Entry(self.root,textvariable = self.type)
        type_field.grid(row = 3,column = 1,ipady = 7,ipadx = 20,padx = 20)

        #=====================Boutton ajout
        add_btn = Button(self.root,text = "Ajouter",command = self.add,anchor='c',image=self.ajoutbuttonimageph,background="white", width=50,height=20)
        add_btn.image=self.ajoutbuttonimageph
        add_btn.grid(row = 5,column = 0,ipady = 4,ipadx = 30,pady = 40)
        #=====================Boutton affichage à ajouter après boutton "Ajouter" dans __init()__
        affich_btn = Button(self.root,text = "Afficher",command = self.view,anchor='c',image=self.affichbuttonimageph,background="white",width=60,height=20)
        affich_btn.image=self.affichbuttonimageph
        affich_btn.grid(row = 5,column = 2,ipady = 4,ipadx = 13,pady = 40) 
        #=====================Boutton Supprimer à ajouter après boutton "Afficher" dans __init()__
        supp_btn = Button(self.root,text = "Supprimer",command = self.remove,anchor='c',image=self.delbuttonimageph,background="white",width=60,height=40)
        supp_btn.image=self.delbuttonimageph
        supp_btn.grid(row = 5,column = 1,ipady = 4,ipadx = 13,pady = 40)
        
       
        
        
        #button_Excel
        exel_btn = Button(self.root,text = "ajouter au fichier Excel",command = self.write_csv,image=self.exbuttonimageph,width = 60,height = 20)
        exel_btn.image=self.exbuttonimageph 
        exel_btn.grid(row = 6,column = 1,ipady = 4,ipadx = 5,pady = 20)
        
         #button_HTML
        html_btn = Button(self.root,text = "ajouter au fichier html",command = self.write_html,image=self.htmlbuttonimageph,width =40,height = 40)
        html_btn.image=self.htmlbuttonimageph 
        html_btn.grid(row = 7,column = 1,ipady = 4,ipadx = 13,pady = 40)
        
        
        #play_button
        
        
        play_btn = Button(self.root,image=self.playbuttonimageph,command = self.play,anchor='c',background="white",width = 60,height = 20)
        play_btn.image=self.playbuttonimageph                                
        play_btn.grid(row = 6,column = 0,ipady = 4,ipadx = 12,pady = 12)
        
        
        
        #stop_button
        stop_btn = Button(self.root,image=self.stopbuttonimageph,command = self.stop,anchor='c',background="white",width = 60,height = 20)
        stop_btn.image=self.stopbuttonimageph
        stop_btn.grid(row = 6,column = 2,ipady = 4,ipadx = 13,pady = 40)
        
        
    #Fonction d'ajout d'un étudiant (sera appelée dérière le boutton "Ajouter"
    def add(self):
        M = Materiel(self.id.get(),self.marque.get(),self.type.get())
        print("Materiel: ",M.marque)
        M.ajouterMateriel()
    def view(self):
        #self.root.title("Student Management(Details)")
        #==========================Show Frame
        self.root=Tk()
        self.root.geometry('700x300')
        self.root.title("Liste des matériaux")
        show_frame = Frame(self.root)
        show_frame.place(width = 800,x = 0,y = 0 ,height = 300)
        show_frame.configure(bg="lightsteelblue")
        labl_show = Label(show_frame,text = "Affichage de fournisseur")
        labl_show.pack()
        
        
        
     
        
        #========================Main Frame
        main_frame = Frame(self.root,bd = 10,relief = SUNKEN)
        main_frame.place(width = 600,height = 200,x = 8,y = 58)
        main_frame.configure(bg="cornflowerblue")
        tree = ttk.Treeview(main_frame,height = 200)
        vsb = ttk.Scrollbar(main_frame,command = tree.yview,orient = "vertical")
        tree.configure(yscroll = vsb.set)
        
        vsb.pack(side = RIGHT,fill = Y)
        tree.pack(side = TOP,fill = X)
        tree['columns'] = ("1","2","3")
        tree.column('#0',width=50)
        tree.column('1',width=80)
        tree.column('2',width=80)
        tree.column('3',width=80)
        tree.heading("#0",text = "Num",anchor='c')
        tree.heading("1",text = "id",anchor='c')
        tree.heading("2",text = "Marque",anchor='w')
        tree.heading("3",text = "Type",anchor='w')
       
    
        
        
        M=Materiel()
        rows=M.afficherMateriel()
        j=1
        for i in rows:

                tree.insert("","end",text=str(j), values = (f'{i[0]}',f'{i[1]}',f'{i[2]}'))
            
    #Fonction dse suppression d'un materiel sera appelée dans le boutton "Supprimer"  
    def remove(self):
        M = Materiel()
        M.supprimerMateriel(self.id.get())
        
   #metier Excel     
    
    def write_csv(self):
            M=Materiel()
            with open('materiel2.csv', 'w') as f:
                w=csv.writer(f)
                w.writerow([M.afficherMateriel()])
        

    
    def play(self):
        pygame.mixer.music.load(r'music.mp3')
        pygame.mixer.music.play(loops=0)
        
    def stop(self):
        pygame.mixer.music.stop()
        
        
        
    #metier html
    
    def write_html(self):
        
        CSV=pd.read_csv("materiel2.csv")
        CSV.to_html("materiel2.html")
        
        

        
   
   
         
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
#if __name__ == "__main__":

root = Tk()
l = GestionMateriel(root)
root.mainloop()


# In[ ]:




