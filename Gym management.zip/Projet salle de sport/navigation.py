#!/usr/bin/env python
# coding: utf-8

# In[1]:


import math

from tkinter import *
from tkinter import messagebox
from tkinter.filedialog import askopenfilename


class MyWindow(Tk):
    
    def __init__(self):
        Tk.__init__(self)
        self.createMenuBar()
        
        # Fill the content of the window

        self.geometry( "300x300" )
        self.title( "MyFirstMenu V1.0" )
    
    def createMenuBar(self):
        menuBar = Menu(self)
        
        menuFile = Menu(menuBar, tearoff=0)
        menuFile.add_command(label="Gerer Materiel", command=self.PageMateriel)
        menuFile.add_command(label="Gerer fournisseur", command=self.PageFournisseur)
        menuFile.add_command(label="Gerer Personnels", command=self.PagePersonnel)
        menuFile.add_command(label="Gerer Roles", command=self.PageRole)
        menuFile.add_command(label="Gerer Abonnee", command=self.PageAbonnee)
        menuFile.add_command(label="Gerer Cours", command=self.PageCours)

        menuFile.add_separator()
        menuBar.add_cascade( label="operations", menu=menuFile)

        
        menuHelp = Menu(menuBar, tearoff=0)
        menuHelp.add_command(label="About")
        menuBar.add_cascade( label="Help")

        self.config(menu = menuBar)        

   
       



        
        
        
    def PageMateriel(self):
        import gestion.py   
        
    def PageFournisseur(self):
        import gestion1.py
        
    def PagePersonnel(self):
        import gestion3.py
    
    def PageRole(self):
        import gestion4.py
        
    def PageAbonnee(self):
        import gestion5.py
        
    def PageCours(self):
        import gestion6.py
        
        
window = MyWindow()
window.mainloop()        


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




