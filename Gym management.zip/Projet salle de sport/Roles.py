#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import mysql.connector

#Classe Role
class Roles:
  #  db=connect_BD()
   # mycursor=db.cursor()
    def __init__(self, id_role=0, description="", disponibilité=""):
        self.id_role=id_role
        self.description=description
        self.disponibilité=disponibilité
        self.db = mysql.connector.connect(
        host="localhost",
        user="Ines",
        password="Inesbennejma24",
        database='salle_de_sport'
        )
        self.mycursor=self.db.cursor()
    #fonction d'ajout dans la table role
    def ajouterRole (self):
        sql = "INSERT INTO tab_role (id_role, description, disponibilité) VALUES (%s, %s, %s)"
        val = (self.id_role, self.description, self.disponibilité)
        self.mycursor.execute(sql, val)
        self.db.commit()
        print(self.mycursor.rowcount, "record inserted.")#optionnel
    #fonction d'affichage de tous les roles
    def afficherRole(self):
        self.mycursor.execute('SELECT * FROM tab_role')
        result=self.mycursor.fetchall()
        return result
        #for row in self.mycursor:
        #print(row)
    #fonction supprimer role
    def supprimerRole(self,id_role):
        sql = "DELETE FROM tab_role WHERE id_role = %s"
        val = (id_role,)
        self.mycursor.execute(sql, val)
        self.db.commit()
        
        

