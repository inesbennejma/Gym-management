#!/usr/bin/env python
# coding: utf-8

# In[1]:


from tkinter import *
from Personnels import Personnels
import PIL
from PIL import ImageTk,Image
import tkinter.ttk as ttk
import pygame
import smtplib
import logging
import sys


class GestionPersonnels():
    def __init__(self,root):
        self.root = root
        self.root.geometry('600x600')
        self.root.title("Gestion Compte")
        #self.load=Image.open(r'personnels.jpg')
        #self.render= ImageTk.PhotoImage(self.load)
        #img= Label(root,image=self.render)
        #img.place(x =0 ,y= 0 , height=600, width=1000)
        self.root.configure(bg = "lightskyblue")
        self.id_personnel=StringVar()
        self.nom=StringVar()
        self.prenom=StringVar()
        self.date_naissance=StringVar()
        pygame.mixer.init()
        
        #self.playbuttonimage=Image.open(r'play1.jpg')
        #self.playbuttonimageph=ImageTk.PhotoImage(self.playbuttonimage)
        
        #self.stopbuttonimage=Image.open(r'stop.png')
        #self.stopbuttonimageph=ImageTk.PhotoImage(self.stopbuttonimage)
        
        #self.ajoutbuttonimage=Image.open(r'ajouter.png')
        #self.ajoutbuttonimageph=ImageTk.PhotoImage(self.ajoutbuttonimage)
        
        #self.affichbuttonimage=Image.open(r'liste.png')
        #self.affichbuttonimageph=ImageTk.PhotoImage(self.affichbuttonimage)
        
        #self.delbuttonimage=Image.open(r'supprimer.jpg')
        #self.delbuttonimageph=ImageTk.PhotoImage(self.delbuttonimage)
        
              
        #self.mailbuttonimage=Image.open(r'mail.png')
        #self.mailbuttonimageph=ImageTk.PhotoImage(self.mailbuttonimage)
       
    #Formulaire ajout Personnel dans __init__()    
    #==============Id personnel TEXTFIELD AND LABEL
        id_personnel_lbl = Label(self.root,text = "Numéro identité personnel",anchor='w')
        id_personnel_lbl.grid(row = 1,column = 0,padx = 40,pady = 40)
        id_personnel_field = Entry(self.root,textvariable = self.id_personnel)
        id_personnel_field.grid(row = 1,column = 1,ipady = 7,ipadx = 20,padx = 20)
    #==============Nom personnel TEXTFIELD AND LABEL
        nom_personnel_lbl = Label(self.root,text = "Nom personnel",anchor='w')
        nom_personnel_lbl.grid(row = 2,column = 0,padx = 40,pady = 40)
        nom_personnel_field = Entry(self.root,textvariable = self.nom)
        nom_personnel_field.grid(row = 2,column = 1,ipady = 7,ipadx = 20,padx = 20)
    #==============Prenom personnel LABEL AND TEXTFIELD
        prenom_lbl = Label(self.root,text="Prénom ",anchor='w')
        prenom_lbl.grid(row = 3,column = 0,pady = 40)
        prenom_field = Entry(self.root,textvariable = self.prenom)
        prenom_field.grid(row = 3,column = 1,ipady = 7,ipadx = 20,padx = 20)
    #==============Date de naissance personnel LABEL AND TEXTFIELD
        date_naissance_lbl = Label(self.root,text="Date naissance personnel ",anchor='w')
        date_naissance_lbl.grid(row = 4,column = 0,pady = 40)
        date_naissance_field = Entry(self.root,textvariable = self.date_naissance)
        date_naissance_field.grid(row = 4,column = 1,ipady = 7,ipadx = 20,padx = 20)
       
        #=====================Boutton ajout
        ajout_personnel_btn = Button(self.root,text = "Ajouter",command = self.add,anchor='c',background="blanchedalmond")
        ajout_personnel_btn.grid(row = 5,column = 0,ipady = 4,ipadx = 30,pady = 40)
        #ajout_personnel_btn.image=self.ajoutbuttonimageph
    
       
        #=====================Boutton Supprimer à ajouter après boutton "Ajouter" dans __init()__
        supp_personnel_btn = Button(self.root,text = "Supprimer",command = self.remove,anchor='c',background="blanchedalmond")
        #supp_personnel_btn.image=self.delbuttonimageph
        supp_personnel_btn.grid(row = 5,column = 1,ipady = 4,ipadx = 13,pady = 40)
        #=====================Boutton affichage à ajouter après boutton "supprimer" dans __init()__
        affichage_personnel_btn = Button(self.root,text = "Afficher",command = self.view,anchor='c',background="blanchedalmond")
        #affichage_personnel_btn.image=self.affichbuttonimageph
        affichage_personnel_btn.grid(row = 5,column = 2,ipady = 4,ipadx = 13,pady = 40)
        
        
        
         #play_button
        
        
        play_btn = Button(self.root,text="Play",command = self.play,anchor='c',background="blanchedalmond")
        #play_btn.image=self.playbuttonimageph                                
        play_btn.grid(row = 6,column = 0,ipady = 4,ipadx = 12,pady = 12)
        
        
        #button_Excel
        exel_personnel_btn = Button(self.root,text = "ajouter au fichier Excel",command = self.write_csv,background="navajowhite",activebackground="orange",borderwidth=8)
        exel_personnel_btn.grid(row = 6,column = 1,ipady = 4,ipadx = 13,pady = 40)
        
        #stop_button
        stop_btn = Button(self.root,text="Stop",command = self.stop,anchor='c',background="blanchedalmond")
        #stop_btn.image=self.stopbuttonimageph
        stop_btn.grid(row = 6,column = 2,ipady = 4,ipadx = 13,pady = 40)
        
        #button mail
        mail_btn = Button(self.root,text="Mail",command = self.mail,anchor='c',background="blanchedalmond")
        #mail_btn.image=self.mailbuttonimageph
        mail_btn.grid(row = 3,column = 3,ipady = 5,ipadx = 30,pady = 40)
    
    #Fonction d'ajout d'un personnel
    def add(self):
        P= Personnels(self.id_personnel.get(),self.nom.get(),self.prenom.get())
        print("Personnel: ",P.typ)
        C.ajouterPersonnel()
        j+=1
    #Fonction de suppression du personnel sera appelée dans le boutton "Supprimer"  
    def remove(self):
        P = Personnels()
        P.supprimerPersonnel(self.id_personnel.get())
    def write_csv(self):
            P=Personnels()
            with open('personnels.csv', 'w') as f:
                w=csv.writer(f)
                w.writerow([M.afficherPersonnel()])
                
                
                
            
        
    def mail(self):#
        sender_email = "rihabmansouri2016@gmail.com"
        rec_email = "nouha.ghoulem@esprit.tn"
        password = input(str("please enter your password : "))
        subject = input(str("please enter the subject : "))
        message = input(str("please enter your message : "))
        msg = f'subject: {subject}\n\n'
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.ehlo()
        server.starttls()
        server.login(sender_email, password)
        print("login success")
        server.sendmail(sender_email, rec_email, message)
        print("email has been sent to ", rec_email )   
        server.close()
    
 
    def view(self):
        self.root=Tk()
        self.root.geometry('700x300')
        self.root.title("gestion personnels")
        show_frame = Frame(self.root)
        show_frame.place(width = 800,x = 0,y = 0 ,height = 300)
        labl_show = Label(show_frame,text = "Affichage du personnel")
        labl_show.pack()
        #========================Main Frame
        main_frame = Frame(self.root,bd = 10,relief = SUNKEN)
        main_frame.place(width = 600,height = 200,x = 8,y = 58)
        tree = ttk.Treeview(main_frame,height = 200)
        vsb = ttk.Scrollbar(main_frame,command = tree.yview,orient = "vertical")
        tree.configure(yscroll = vsb.set)
        vsb.pack(side = RIGHT,fill = Y)
        tree.pack(side = TOP,fill = X)
        tree['columns'] = ("1","2","3")
        tree.column('#0',width=50)
        tree.column('1',width=80)
        tree.column('2',width=80)
        tree.column('3',width=80)
        tree.column('4',width=80)
        tree.heading("#0",text = "Num",anchor='c')
        tree.heading("1",text = "id_personnel",anchor='c')
        tree.heading("2",text = "nom",anchor='w')
        tree.heading("3",text = "prenom",anchor='w')
        tree.heading("4",text = "date_naissance",anchor='w')
        P=Personnel()
        rows=P.afficherCompte()
        j=1
        for i in rows:
            tree.insert("","end",text=str(j), values = (f'{i[0]}',f'{i[1]}',f'{i[2]}',f'{i[3]}'))
            j+=1  
    def remove(self):
        P = Personnel()
        P.supprimerPersonnel(self.id_personnel.get())
    def play(self):
        pygame.mixer.music.load(r'motivation.mp3')
        pygame.mixer.music.play(loops=0)
    def stop(self):
        pygame.mixer.music.stop()
#if __name__ == "__main__":
root = Tk()
l = GestionPersonnels(root)
root.mainloop()


# In[ ]:





# In[ ]:




