#!/usr/bin/env python
# coding: utf-8

# In[ ]:



import mysql.connector

class Fournisseur:
  #  db=connect_BD()
   # mycursor=db.cursor()
    def __init__(self,num="",n="",d="",ad=""):
        self.numf=num
        self.nom=n
        self.domaine=d
        self.adresse=ad
        self.db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root123456",
        database="salle_de_sport"
        )
        self.mycursor=self.db.cursor()
    #fonction d'ajout dans la table etudiant
    def ajouterFournisseur (self):
        sql = "INSERT INTO fournisseur (numf, nom, domaine, adresse) VALUES (%s, %s, %s, %s)"
        val = (self.numf, self.nom, self.domaine, self.adresse)
        self.mycursor.execute(sql, val)
        self.db.commit()
        print(self.mycursor.rowcount, "record inserted.")#optionnel
    #fonction d'affichage de tous les étudiants
    def afficherFournisseur(self):
        self.mycursor.execute('SELECT * FROM fournisseur')
        result=self.mycursor.fetchall()
        return result
        #for row in self.mycursor:
        #print(row)
    #fonction supprimer etudiant
    def supprimerFournisseur(self,num):
        sql = "DELETE FROM fournisseur WHERE numf = %s"
        val = (num,)
        self.mycursor.execute(sql, val)
        self.db.commit()
        






